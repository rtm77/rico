const help = (prefix, ownerBot, botName) => {
        return `botronaldo`
}
exports.help = help
