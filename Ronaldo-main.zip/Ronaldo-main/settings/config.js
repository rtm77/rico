const config = {
        botName: 'botronaldo',
        ownerName: 'botronaldo',
        
}
