const antimenu = (prefix, pushname) => {
    return `

*Comandos Para Activar Los Antilinks 📢*

══════════════

_*Antilink De Grupos De Whatsapp*_

*PARA ACTIVAR EL ANTILINK*
${prefix}antilink 1

*PARA DESACTIVAR EL ANTILINK*
${prefix}antilink 0

══════════════

_*Antilink De Instagram*_

*PARA ACTIVAR EL ANTILINK*
${prefix}antinsta 1

*PARA DESACTIVAR EL ANTILINK*
${prefix}antinsta 0

══════════════

_*Antilink De Facebook*_

*PARA ACTIVAR EL ANTILINK*
${prefix}antiface 1

*PARA DESACTIVAR EL ANTILINK*
${prefix}antiface 0

══════════════

_*Antilink De Tik Tok*_

*PARA ACTIVAR EL ANTILINK*
${prefix}antitik 1

*PARA DESACTIVAR EL ANTILINK*
${prefix}antitik 0

══════════════


_*Antilink De Kwai*_

*PARA ACTIVAR EL ANTILINK*
${prefix}antikwai 1

*PARA DESACTIVAR EL ANTILINK*
${prefix}antikwai 0
 
══════════════


_*Antilink De Discord*_

*PARA ACTIVAR EL ANTILINK*
${prefix}antidiscord 1

*PARA DESACTIVAR EL ANTILINK*
${prefix}antidiscord 0
 
══════════════

_Para activar estos comandos el bot necesita tener admin en el grupo y esta funcion solo la activan los admins del grupo_


ву ѕнαη∂υу
`

}

exports.antimenu = antimenu
