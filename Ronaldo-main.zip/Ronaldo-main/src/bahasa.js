const bahasa = (prefix, sender) => {
	return `ronaldoboot`
}

exports.bahasa = bahasa
