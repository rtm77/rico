const banmenu = (prefix, pushname) => {
    return `ronaldoboot`

}

exports.banmenu = banmenu
