const desmenu = (prefix, pushname) => {
    return `bootronaldo`

}

exports.desmenu = desmenu
