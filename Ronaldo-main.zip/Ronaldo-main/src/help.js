const help = (prefix) => {
	return `ronaldobot`
}

exports.help = help
