const juegos = (prefix, pushname) => {
    return `ronaldoboot`

}

exports.juegos = juegos
