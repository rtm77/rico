const negara = (prefix, sender) => {
	return `ronaldobot`
}

exports.negara = negara
